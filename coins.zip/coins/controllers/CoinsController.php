<?php

namespace app\controllers;

use Yii;
use yii\data\ActiveDataProvider;
use yii\db\Query;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\Users;
use app\models\Offices;
use app\models\Roles;
use app\models\Settings;
use app\models\Statistics;
use app\models\Transactions;
use app\assets\CoinAsset;


class CoinsController extends Controller
{

    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }
    public function actionDashboard()
    {
        //var_dump(Yii::$app->formatter->asDate('2021-10-20') == Yii::$app->formatter->asDate('21.10.2021'));
       //$model = Users::find()->where('id'== 1)->one();
//        var_dump(Yii::$app->user);die;
//        var_dump(Yii::$app->user->getId());


        $coins = Yii::$app->db->createCommand("SELECT users.id as id, users.name as name, settings.nascent_coins as nascent_start_coins,
        settings.bonus_coins as bonus_start_coins, statistics.nascent_coins as nascent_now_coins, statistics.bonus_coins as bonus_now_coins, 
        transactions.donor_user_id as donor_id, transactions.recipient_user_id as recipient_id, actions.id as action, transactions.coins as coins 
        FROM users 
        LEFT JOIN statistics ON users.id = statistics.user_id
        LEFT JOIN transactions ON users.id = transactions.donor_user_id 
        LEFT JOIN roles ON users.role_id = roles.id 
        LEFT JOIN offices ON users.office_id = offices.id
        LEFT JOIN settings ON roles.id = settings.role_id 
        LEFT JOIN actions ON transactions.action_id = actions.id
        WHERE users.id = 1")
        ->queryAll();
        $coins[0]['quart'] = 'January-April';
        $coins[0]['year'] = '2020';
        $coins[0]['year_bonus_coins'] = 50;
//        $query = Yii::$app->db->createCommand("SELECT transactions.date as Date, users.name as Name, transactions.action_id as Action, transactions.coins as Coins,
//        transactions.comment as Reason FROM transactions
//        JOIN users ON transactions.donor_user_id = users.id
//        WHERE transactions.donor_user_id = users.id
//        ")->query();
        $query = new Query();

        $query->select('transactions.date , users.name , actions.title as action, transactions.coins , 
        transactions.comment ')->from('`transactions`')->Leftjoin('users', '`transactions`.`donor_user_id` = `users`.`id`')
            ->leftJoin('actions', '`transactions`.`action_id` = `actions`.`id`')
            ->where((['recipient_user_id' => 1]  ));
       // var_dump($query);die;
        $data = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' =>20,
                ],
            ]);

        $query = new Query();
        $query->select('users.name as Name,  statistics.bonus_coins as Total_Coins')->from('statistics')
            ->leftJoin('users', 'statistics.user_id = users.id')->where(['users.office_id'=>1])->orderBy(['bonus_coins'=>SORT_DESC]);
       //var_dump($query);die;
        $dataOfficeLead = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' =>20,
            ],]);
        $query1 = new Query();
        $query1->select('users.name as Name, offices.title as Office,  statistics.bonus_coins as Total')->from('statistics')
            ->leftJoin('users', 'statistics.user_id = users.id')->leftJoin('offices', 'users.office_id = offices.id')->orderBy(['bonus_coins'=>SORT_DESC]);

        $dataWorldLead = new ActiveDataProvider([
            'query' => $query1,
            'pagination' =>[
                'pageSize' => 20,
            ]
        ]);

        $count = 0;
        return $this->render('dashboard', ['model'=>$coins, 'data' => $data, 'dataOfficeLead' => $dataOfficeLead, 'dataWorldLead'=>$dataWorldLead, 'count'=>$count] );

    }
}