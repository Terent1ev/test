<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "transactions".
 *
 * @property int $ID
 * @property int $donor_user_id
 * @property int $recipient_user_id
 * @property int $action_id
 * @property string $date
 * @property int $coins
 * @property string $comment
 *
 * @property Actions $action
 * @property Users $donorUser
 * @property Users $recipientUser
 */
class Transactions extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'transactions';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['donor_user_id', 'recipient_user_id', 'action_id', 'coins', 'comment'], 'required'],
            [['donor_user_id', 'recipient_user_id', 'action_id', 'coins'], 'integer'],
            [['date'], 'safe'],
            [['comment'], 'string', 'max' => 1024],
            [['action_id'], 'unique'],
            [['donor_user_id'], 'unique'],
            [['recipient_user_id'], 'unique'],
            [['action_id'], 'exist', 'skipOnError' => true, 'targetClass' => Actions::className(), 'targetAttribute' => ['action_id' => 'ID']],
            [['donor_user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['donor_user_id' => 'ID']],
            [['recipient_user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Users::className(), 'targetAttribute' => ['recipient_user_id' => 'ID']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => 'ID',
            'donor_user_id' => 'Donor User ID',
            'recipient_user_id' => 'Recipient User ID',
            'action_id' => 'Action ID',
            'date' => 'Date',
            'coins' => 'Coins',
            'comment' => 'Comment',
        ];
    }

    /**
     * Gets query for [[Action]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAction()
    {
        return $this->hasOne(Actions::className(), ['ID' => 'action_id']);
    }

    /**
     * Gets query for [[DonorUser]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDonorUser()
    {
        return $this->hasOne(Users::className(), ['ID' => 'donor_user_id']);
    }

    /**
     * Gets query for [[RecipientUser]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRecipientUser()
    {
        return $this->hasOne(Users::className(), ['ID' => 'recipient_user_id']);
    }
}
