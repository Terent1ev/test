<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "users".
 *
 * @property int $ID
 * @property string $name
 * @property int $office_id
 * @property int $role_id
 *
 * @property Statistics $statistics
 * @property Transactions $transactions
 * @property Transactions $transactions0
 * @property Settings $role
 * @property Offices $office
 */
class Users extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'users';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['name', 'office_id', 'role_id'], 'required'],
            [['office_id', 'role_id'], 'integer'],
            [['name'], 'string', 'max' => 255],
            [['office_id'], 'unique'],
            [['role_id'], 'unique'],
            [['role_id'], 'exist', 'skipOnError' => true, 'targetClass' => Settings::className(), 'targetAttribute' => ['role_id' => 'role_id']],
            [['office_id'], 'exist', 'skipOnError' => true, 'targetClass' => Offices::className(), 'targetAttribute' => ['office_id' => 'ID']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'ID' => 'ID',
            'name' => 'Name',
            'office_id' => 'Office ID',
            'role_id' => 'Role ID',
        ];
    }

    /**
     * Gets query for [[Statistics]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getStatistics()
    {
        return $this->hasOne(Statistics::className(), ['user_id' => 'ID']);
    }

    /**
     * Gets query for [[Transactions]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions()
    {
        return $this->hasOne(Transactions::className(), ['donor_user_id' => 'ID']);
    }

    /**
     * Gets query for [[Transactions0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTransactions0()
    {
        return $this->hasOne(Transactions::className(), ['recipient_user_id' => 'ID']);
    }

    /**
     * Gets query for [[Role]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRole()
    {
        return $this->hasOne(Settings::className(), ['role_id' => 'role_id']);
    }

    /**
     * Gets query for [[Office]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getOffice()
    {
        return $this->hasOne(Offices::className(), ['ID' => 'office_id']);
    }
}
