<?php
/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use yii\grid\GridView;
?>
<div class="page" >
    <div class="page__header" >
        <h2>Dashboard</h2>
    </div>
    <div class="page__content" >
        <div class="page__content__body" >
            <div class="page__content__body__card__wrap" >

                <!--current coins-->
                <div class="page__content__body__card dashboard__current-coins__wrap" >
                    <div class="dashboard__current-coins">
                        <div class="dashboard__current-coins__period__wrap">
                            <div class="dashboard__current-coins__period">
                                <h4 class="dashboard__current-coins__period__title"><?= $model[0]['year']?></h4>
                                <div class="dashboard__current-coins__period__circle"><p class="dashboard__current-coins__period__circle__number"><?= $model[0]['year_bonus_coins']?></p><p>bonus<br> coins</p></div>
                            </div>
                            <div class="dashboard__current-coins__period">
                                <h4 class="dashboard__current-coins__period__title"><?= $model[0]['quart'] ?></h4>
                                <div class="dashboard__current-coins__period__circle"><p class="dashboard__current-coins__period__circle__number"><?= (int)$model[0]['bonus_now_coins'] ?></p><p>bonus<br> coins</p></div>
                            </div>
                        </div>
                        <h4 class="dashboard__current-coins__title-current">Current month</h4>
                        <h5 class="dashboard__current-coins__title-type">Bonus coins:</h5>
                        <div class="dashboard__current-coins__coins-block">
                        <?php for($i = 0; $i<8-(int)$model[0]['bonus_now_coins']; $i++) {?>
                            <div class="coin coin--empty">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                            <?php }; for ($i = 0; $i<(int)$model[0]['bonus_now_coins']; $i++) {?>
                            <div class="coin coin--full">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                            <?php }?>
                        </div>

                        <h5 class="dashboard__current-coins__title-type">Nascent coins:</h5>
                        <div class="dashboard__current-coins__coins-block">
                            <?php for ($i=0;$i<(int)$model[0]['nascent_now_coins']; $i++) {?>
                            <div class="coin coin--full">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                           <?php } ?>
                        </div>
                    </div>
                </div>

                <!--leaderboard & transactions-->
                <div class="page__content__body__card dashboard__leaderboards__wrap">
                    <div class="dashboard__leaderboards">
                        <h4 class="dashboard__leaderboards__title">Worldwide leaderboard</h4>
                        <div class="dashboard__leaderboards__table">
                            <?= GridView::widget([
                                    'dataProvider' =>$dataWorldLead,
                                    'summary' => false,
                                    'columns' => [
                                        ['class' => 'yii\grid\SerialColumn'],
                                        'Name',
                                        'Office',
                                        'Total',
                                    ]
                            ]); ?>
                        </div>
                        <h4 class="dashboard__leaderboards__title">Office leaderboard</h4>
                        <div class="dashboard__leaderboards__table">
                            <?= GridView::widget([
                                'dataProvider' => $dataOfficeLead,
                                'summary' => false,
                                'columns'=>[
                                    ['class' => 'yii\grid\SerialColumn'],
                                    'Name',
                                    'Total_Coins'
                                    ]
                            ]);?>
                        </div>
                        <h4 class="dashboard__leaderboards__title">Transaction history</h4>
                        <div class="dashboard__leaderboards__table">
                           <?= GridView::widget([
                               'dataProvider' => $data,
                               'summary' => false,
                            ]);?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="page__content__body__card__wrap"
                <!--Bounty cards-->
                <div class="page__content__body__card dashboard__bounty-cards__wrap">
                    <h4 class="dashboard__bounty-cards__title">Your bounty cards</h4>
                    <div class="dashboard__bounty-cards">
                        <div class="dashboard__bounty-cards__card">
                            <p class="dashboard__bounty-cards__card__description">Create back-end for the coin dashboard</p>
                            <p class="dashboard__bounty-cards__card__points">2</p>
                            <p class="dashboard__bounty-cards__card__creator">From: Maksim Mikhelson</p>
                        </div>
                        <div class="dashboard__bounty-cards__card">
                            <p class="dashboard__bounty-cards__card__description">Create back-end for the coin dashboard</p>
                            <p class="dashboard__bounty-cards__card__points">2</p>
                            <p class="dashboard__bounty-cards__card__creator">From: Maksim Mikhelson</p>
                        </div>
                        <div class="dashboard__bounty-cards__card">
                            <p class="dashboard__bounty-cards__card__description">Create back-end for the coin dashboard</p>
                            <p class="dashboard__bounty-cards__card__points">2</p>
                            <p class="dashboard__bounty-cards__card__creator">From: Maksim Mikhelson</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
