<?php

/* @var $this \yii\web\View */
/* @var $content string */
namespace app\models;
use app\widgets\Alert;
use yii\base\Widget;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\CoinAsset;
use app\models\Users;


CoinAsset::register($this);

?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>gulp-scss-starter</title>
        <meta name="theme-color" content="#fff">
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
        <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <link rel="shortcut icon" href="../img/favicons/favicon.ico" type="image/x-icon">
        <link rel="icon" sizes="16x16" href="../img/favicons/favicon-16x16.png" type="image/png">
        <link rel="icon" sizes="32x32" href="../img/favicons/favicon-32x32.png" type="image/png">
        <link rel="apple-touch-icon-precomposed" href="../img/favicons/apple-touch-icon-precomposed.png">
        <link rel="apple-touch-icon" href="../img/favicons/apple-touch-icon.png">
        <link rel="apple-touch-icon" sizes="57x57" href="../img/favicons/apple-touch-icon-57x57.png">
        <link rel="apple-touch-icon" sizes="60x60" href="../img/favicons/apple-touch-icon-60x60.png">
        <link rel="apple-touch-icon" sizes="72x72" href="../img/favicons/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="76x76" href="../img/favicons/apple-touch-icon-76x76.png">
        <link rel="apple-touch-icon" sizes="114x114" href="../img/favicons/apple-touch-icon-114x114.png">
        <link rel="apple-touch-icon" sizes="120x120" href="../img/favicons/apple-touch-icon-120x120.png">
        <link rel="apple-touch-icon" sizes="144x144" href="../img/favicons/apple-touch-icon-144x144.png">
        <link rel="apple-touch-icon" sizes="152x152" href="../img/favicons/apple-touch-icon-152x152.png">
        <link rel="apple-touch-icon" sizes="167x167" href="../img/favicons/apple-touch-icon-167x167.png">
        <link rel="apple-touch-icon" sizes="180x180" href="../img/favicons/apple-touch-icon-180x180.png">
        <link rel="apple-touch-icon" sizes="1024x1024" href="../img/favicons/apple-touch-icon-1024x1024.png">
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>
    <div class="header">
        <div class="header__profile">
            <span class="heared__profile__name"><?= Alert::widget() ?></span>
            <img class="header__profile__img" src="img/icon_user.png" alt="user">
            <img class="header__profile__arrow-down" src="img/icon_arrow-down.svg" alt="arrow-down">
            <div class="header__log-out">
                <a href="#"><i class="fas fa-sign-out-alt"></i>Log out</a>
            </div>
        </div>
    </div>
    <div class="nav">
        <div class="nav__logo">
            <img class="nav__logo__img" src="img/logo.png" alt="logo">
            <span class="nav__logo__text">Bonus Coins</span>
        </div>
        <div class="nav__menu">
            <ul class="nav__menu__list">
                <li class="nav__menu__list__item active"><a href="#"><i class="fas fa-home"></i>Dashboard</a></li>
                <li class="nav__menu__list__item"><a href="#"><i class="fas fa-bookmark"></i>Bounty cards</a></li>
                <li class="nav__menu__list__item"><a href="#"><i class="fas fa-book"></i>Rules</a></li>
                <li class="nav__menu__list__item"><a href="#"><i class="fas fa-cog"></i>Settings</a></li>
            </ul>
        </div>
    </div>
    <?= $content ?>
<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
