<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>gulp-scss-starter</title>
    <meta name="theme-color" content="#fff">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="shortcut icon" href="/img/favicons/favicon.ico" type="image/x-icon">
    <link rel="icon" sizes="16x16" href="/img/favicons/favicon-16x16.png" type="image/png">
    <link rel="icon" sizes="32x32" href="/img/favicons/favicon-32x32.png" type="image/png">
    <link rel="apple-touch-icon-precomposed" href="/img/favicons/apple-touch-icon-precomposed.png">
    <link rel="apple-touch-icon" href="/img/favicons/apple-touch-icon.png">
    <link rel="apple-touch-icon" sizes="57x57" href="/img/favicons/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/img/favicons/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/img/favicons/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/img/favicons/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/img/favicons/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/img/favicons/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/img/favicons/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/img/favicons/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="167x167" href="/img/favicons/apple-touch-icon-167x167.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/favicons/apple-touch-icon-180x180.png">
    <link rel="apple-touch-icon" sizes="1024x1024" href="/img/favicons/apple-touch-icon-1024x1024.png">
</head>
<body>
<div class="header">
    <div class="header__profile">
        <span class="heared__profile__name">Admin</span>
        <img class="header__profile__img" src="img/icon_user.png" alt="user">
        <img class="header__profile__arrow-down" src="img/icon_arrow-down.svg" alt="arrow-down">
        <div class="header__log-out">
            <a href="#"><i class="fas fa-sign-out-alt"></i>Log out</a>
        </div>
    </div>
</div>
<div class="nav" >
    <div class="nav__logo">
        <img class="nav__logo__img" src="img/logo.png" alt="logo">
        <span class="nav__logo__text">Bonus Coins</span>
    </div>
    <div class="nav__menu" >
        <ul class="nav__menu__list">
            <li class="nav__menu__list__item active"><a href="#"><i class="fas fa-home"></i>Dashboard</a></li>
            <li class="nav__menu__list__item"><a href="#"><i class="fas fa-bookmark"></i>Bounty cards</a></li>
            <li class="nav__menu__list__item"><a href="#"><i class="fas fa-book"></i>Rules</a></li>
            <li class="nav__menu__list__item"><a href="#"><i class="fas fa-cog"></i>Settings</a></li>
        </ul>
    </div>
</div>
<div class="page" >
    <div class="page__header" >
        <h2>Dashboard</h2>
    </div>
    <div class="page__content" >
        <div class="page__content__body" >
            <div class="page__content__body__card__wrap" >

                <!--current coins-->
                <div class="page__content__body__card dashboard__current-coins__wrap" >
                    <div class="dashboard__current-coins">
                        <div class="dashboard__current-coins__period__wrap">
                            <div class="dashboard__current-coins__period">
                                <h4 class="dashboard__current-coins__period__title">Year</h4>
                                <div class="dashboard__current-coins__period__circle"><p class="dashboard__current-coins__period__circle__number">30</p><p>bonus<br> coins</p></div>
                            </div>
                            <div class="dashboard__current-coins__period">
                                <h4 class="dashboard__current-coins__period__title">Quarter (January&nbsp;-&nbsp;March)</h4>
                                <div class="dashboard__current-coins__period__circle"><p class="dashboard__current-coins__period__circle__number">6</p><p>bonus<br> coins</p></div>
                            </div>
                        </div>
                        <h4 class="dashboard__current-coins__title-current">Current month</h4>
                        <h5 class="dashboard__current-coins__title-type">Bonus coins:</h5>
                        <div class="dashboard__current-coins__coins-block">
                            <div class="coin coin--empty" >
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                            <div class="coin coin--empty">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                            <div class="coin coin--empty">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                            <div class="coin coin--empty">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                            <div class="coin coin--full">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                            <div class="coin coin--full">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                        </div>
                        <h5 class="dashboard__current-coins__title-type">Nascent coins:</h5>
                        <div class="dashboard__current-coins__coins-block">
                            <div class="coin coin--full">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                            <div class="coin coin--full">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                            <div class="coin coin--full">
                                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                                <span class="letter1">G</span>
                                <span class="letter2">o</span>
                                <span class="letter3">D</span>
                                <span class="letter4">i</span>
                                <span class="letter5">g</span>
                                <span class="letter6">i</span>
                                <span class="letter7">t</span>
                                <span class="letter8">a</span>
                                <span class="letter9">l</span>
                                <span class="letter10"> </span>
                                <span class="letter11">M</span>
                                <span class="letter12">e</span>
                                <span class="letter13">d</span>
                                <span class="letter14">i</span>
                                <span class="letter15">a</span>
                                <span class="letter16"> </span>
                                <span class="letter17">G</span>
                                <span class="letter18">r</span>
                                <span class="letter19">o</span>
                                <span class="letter20">u</span>
                                <span class="letter21">p</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!--leaderboard & transactions-->
                <div class="page__content__body__card dashboard__leaderboards__wrap">
                    <div class="dashboard__leaderboards">
                        <h4 class="dashboard__leaderboards__title">Worldwide leaderboard</h4>
                        <div class="dashboard__leaderboards__table">

                            <table>
                                <tr>
                                    <th>Rank</th>
                                    <th>Name</th>
                                    <th>Office</th>
                                    <th>Total</th>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>Max</td>
                                    <td>Vitebsk</td>
                                    <td>50</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Alex</td>
                                    <td>Vitebsk</td>
                                    <td>45</td>
                                </tr>
                            </table>
                        </div>
                        <h4 class="dashboard__leaderboards__title">Office leaderboard</h4>
                        <div class="dashboard__leaderboards__table">
                            <table>
                                <tr>
                                    <th>Rank</th>
                                    <th>Name</th>
                                    <th>Coin total</th>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>Max</td>
                                    <td>50</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Alex</td>
                                    <td>45</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Pavel</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Alena</td>
                                    <td>35</td>
                                </tr>
                            </table>
                        </div>
                        <h4 class="dashboard__leaderboards__title">Transaction history</h4>
                        <div class="dashboard__leaderboards__table">
                            <table>
                                <tr>
                                    <th>Date/Time</th>
                                    <th>Name</th>
                                    <th>Action</th>
                                    <th>Coins</th>
                                    <th>Reason</th>
                                </tr>
                                <tr>
                                    <td>12/08/2019</td>
                                    <td>Vasia</td>
                                    <td>Take</td>
                                    <td>2</td>
                                    <td>Screwed up</td>
                                </tr>
                                <tr>
                                    <td>12/08/2019</td>
                                    <td>Max</td>
                                    <td>Give</td>
                                    <td>2</td>
                                    <td>Good boy</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="page__content__body__card__wrap">

                <!--Bounty cards-->
                <div class="page__content__body__card dashboard__bounty-cards__wrap">
                    <h4 class="dashboard__bounty-cards__title">Your bounty cards</h4>
                    <div class="dashboard__bounty-cards">
                        <div class="dashboard__bounty-cards__card">
                            <p class="dashboard__bounty-cards__card__description">Create back-end for the coin dashboard</p>
                            <p class="dashboard__bounty-cards__card__points">2</p>
                            <p class="dashboard__bounty-cards__card__creator">From: Maksim Mikhelson</p>
                        </div>
                        <div class="dashboard__bounty-cards__card">
                            <p class="dashboard__bounty-cards__card__description">Create back-end for the coin dashboard</p>
                            <p class="dashboard__bounty-cards__card__points">2</p>
                            <p class="dashboard__bounty-cards__card__creator">From: Maksim Mikhelson</p>
                        </div>
                        <div class="dashboard__bounty-cards__card">
                            <p class="dashboard__bounty-cards__card__description">Create back-end for the coin dashboard</p>
                            <p class="dashboard__bounty-cards__card__points">2</p>
                            <p class="dashboard__bounty-cards__card__creator">From: Maksim Mikhelson</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

</body>
</html>