<?php
namespace app\widgets;
use app\models\Users;
use Yii;


class Alert extends \yii\bootstrap\Widget
{


    public function init()
    {
        parent::init();
    }

    public function run()
    {
        parent::run();
        $model = Users::find()->where('id'== 1)->one();
        return $model['name'];
    }
}
