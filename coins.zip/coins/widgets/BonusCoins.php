<?php
namespace app\widgets;
use app\models\Users;
use Yii;


class BonusCoins extends \yii\bootstrap\Widget
{


    public function init()
    {
        parent::init();
    }

    public function run()
    {
        parent::run();
        for ($i = 0; $i < (int)$model[0]['nascent_now_coins']; $i++) { ?>
            <div class="coin coin--full">
                <img src="img/logo-gdmg-white.svg" class="coin__symbol">
                <span class="letter1">G</span>
                <span class="letter2">o</span>
                <span class="letter3">D</span>
                <span class="letter4">i</span>
                <span class="letter5">g</span>
                <span class="letter6">i</span>
                <span class="letter7">t</span>
                <span class="letter8">a</span>
                <span class="letter9">l</span>
                <span class="letter10"> </span>
                <span class="letter11">M</span>
                <span class="letter12">e</span>
                <span class="letter13">d</span>
                <span class="letter14">i</span>
                <span class="letter15">a</span>
                <span class="letter16"> </span>
                <span class="letter17">G</span>
                <span class="letter18">r</span>
                <span class="letter19">o</span>
                <span class="letter20">u</span>
                <span class="letter21">p</span>
            </div>

            <?php
        }
    }
}
?>